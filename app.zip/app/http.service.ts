import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  countries: any;
  countryStates: any;

  constructor(private http: HttpClient) { }

  getBeer() {
    return this.http.get('https://api.openbrewerydb.org/breweries')
  }

  getCountries() {
    return this.http.get('./assets/countries+states.json')
  }

  getCountryStates(country) {
    for (var i=0; i < this.countries.length; i++) {
          if (country==this.countries[i].name) {
               this.countryStates = this.countries[i].states
          }
        }
  }
}
