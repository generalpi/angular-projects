import { Component, OnInit } from '@angular/core';

import { HttpService } from '../../app/http.service';

@Component({
  selector: 'app-states',
  templateUrl: './states.component.html',
  styleUrls: ['./states.component.scss']
})
export class StatesComponent implements OnInit {

  country: any;

  constructor(private http: HttpService) { }

  ngOnInit() {
    this.http.getCountryStates(this.country).subscribe((data: any) => {
      this.country = data;
      console.log(this.country);
    }
  );
  }

}
